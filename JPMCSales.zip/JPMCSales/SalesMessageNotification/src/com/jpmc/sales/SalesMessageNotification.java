package com.jpmc.sales;

import java.io.BufferedReader;
import java.io.FileReader;

import com.jpmc.sales.process.Sale;;

public class SalesMessageNotification {
	public static void main(String[] args) {
		Sale sale = new Sale();
		try {
			String line;
			BufferedReader inputFile = new BufferedReader(new FileReader("Input/input.txt"));
			while ((line = inputFile.readLine()) != null) {
				sale.processNotification(line);
				sale.log.report();
			}
		} catch (java.io.IOException e) {
			e.printStackTrace();
		}
	}
}
